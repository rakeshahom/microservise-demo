package com.apigateway.apigateway.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ServiceFallBackController {

	@GetMapping("/custservice")
	public String custService() {

		return "customer service is down............!";
	}

	@GetMapping("/productservice")
	public String productService() {

		return "Product service is down............!";
	}
}
