package com.customerService.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Customer {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int custId;
	private String cust_name;
	private String cust_address;
	private int pid;
	public Customer(int custId, String cust_name, String cust_address, int pid) {
		super();
		this.custId = custId;
		this.cust_name = cust_name;
		this.cust_address = cust_address;
		this.pid = pid;
	}
	public Customer() {
		super();
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public String getCust_address() {
		return cust_address;
	}
	public void setCust_address(String cust_address) {
		this.cust_address = cust_address;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	@Override
	public String toString() {
		return "CustomerService [custId=" + custId + ", cust_name=" + cust_name + ", cust_address=" + cust_address
				+ ", pid=" + pid + "]";
	}
	
}
