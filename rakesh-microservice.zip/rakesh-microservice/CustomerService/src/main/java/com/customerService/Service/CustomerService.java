package com.customerService.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.customerService.Model.Customer;
import com.customerService.Model.Product;
import com.customerService.Repository.CustomerRepository;
import com.customerService.classes.MyOrders;

@Service
public class CustomerService {
	
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	private CustomerRepository customerRepository;

	public Customer saveCustomer(Customer custService) {

		return customerRepository.save(custService);
	}

	public MyOrders getMyOrders(int custId) {

		Optional<Customer> cust = customerRepository.findById(custId);
		
		int pid = cust.get().getPid();
		
		Product product = restTemplate.getForObject("http://product-service/product/" + pid, Product.class);
		
		MyOrders myOrders = new MyOrders();          //create an object of myorders class
		myOrders.setCustomer(cust.get());            //return all details of customer
		myOrders.setProduct(product);                //return all details productsof customer
		
		return myOrders;
		
	}
}









