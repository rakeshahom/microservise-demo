package com.serviceregistryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRegistryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
