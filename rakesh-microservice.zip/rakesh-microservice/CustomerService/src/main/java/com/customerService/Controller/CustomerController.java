package com.customerService.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.customerService.Model.Customer;
import com.customerService.Service.CustomerService;
import com.customerService.classes.MyOrders;

@RestController
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	
	@PostMapping("/add")
	public Customer saveCustomer(@RequestBody Customer customer) {

		return customerService.saveCustomer(customer);
	}

	@GetMapping("/myorders/{cid}")
	public MyOrders mhyProductOrders(@PathVariable("cid") int custId) {
		return customerService.getMyOrders(custId);
	}
}
