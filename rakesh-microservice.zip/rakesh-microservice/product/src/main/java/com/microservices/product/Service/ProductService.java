package com.microservices.product.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservices.product.Entity.Product;
import com.microservices.product.Repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	ProductRepository productRepository;
	
	public Product saveProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepository.save(product);
	}

	public Optional<Product> getProductById(int pid) {
		// TODO Auto-generated method stub
		return productRepository.findById(pid);
	}
	
	public List<Product>getAllProduct(){
		return productRepository.findAll();
	}
	
}
